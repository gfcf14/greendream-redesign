EMPLOYMENT ASSISTANT
--------------------

To run: Simply click on the executable file of the program.

Instructions: 

You must fill out a name for the company to apply (like Apple), the type of application from a combo box, its life (some last from a month to half a year; if you are not sure simply select a month) and enter:

the address for 'Walk-in' or 'Print & Bring',
the e-mail of the company for 'E-mail Resume', or
the web address of the career site of the company for 'Apply Online' , in the last text box

Once you are done, press 'Store'. A file named applications.txt will appear.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

DO NOT ERASE THAT FILE!! Or you'll lose ALL your applications

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Once you have at least one application, you may edit it or delete it as you wish with the 'Edit' button
With two or more applications, you may use the '<<<' and '>>>' buttons to cycle through them to check their info

Tips:

- If you open applications.txt and compare a line of it with its corresponding application number on the program, you may be able to modify them by hand (the last number is the day in the year applied (December 31 = 365 or 366 if leap)), but only do so if you know what you are doing. To be on the safe side, make a copy of the file BEFORE modifying anything.
- If you wish to move EmploymentAssistant.exe to another location, make sure you move applications.txt as well, if it exists

- WINDOWS USERS: To have this exe run on pc start up, do the following:

1. Right click the application, and select 'Send to...Desktop(create shortcut)
2. Press the windows logo on the keyboard, click 'All Programs', then find the 'Startup' folder. Right click it and select 'Open'
3. Go back to the desktop, and cut the shortcut icon (Ctrl + X)
4. Go back to the Startup folder, and paste it there (Ctrl + V)

	If you change the location of EmploymentAssistant.exe, you would have to re-do these steps and erase the old shortcut
